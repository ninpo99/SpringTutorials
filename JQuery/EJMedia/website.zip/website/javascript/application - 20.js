	$("img").load(function() {
         
          alert("the Caesar image has loaded");
		$('#testButton').css({'position':'fixed','left':20,'bottom':20});

		// $('img').mouseover(function(event) {
		// 	// $('p').text('All hail Julius Caesar');
		// 	// $('#right').append('<p>Hey you just moused over Julius</p>');
		// 	$('#right').after('<p>Hey you just moused over Julius</p>');
		// });

		// $('button').mouseover(function(event) {
		// 	$('button').css('color','red');
		// });

		// $('#right').hover(function() {
		// 	$('div').css('background-color','yellow')
		// }, function() {
		// 	$('div').css('background-color','grey')
		// });

		// $('#right').hover(function() {
		// 	$('img').show()
		// }, function() {
		// 	$('img').hide()
		// });



		$('button').click(function(event) {
			// 	$('#right').hide();
			// 	$('div:not(#test,#center)').hide();
			// 	$('#left p:first').hide();
			// 	$('div:even').hide();
			// 	$('div:odd').hide();
			//  $('div:last').hide();
			// 	$("p:contains('center')").hide();
			// 	$('div:has(b)').hide();
			// 	$('body div:nth-child(3)').hide();
			// 	$('li:empty').hide();
			// 	$('#left').css('color','blue');
			// 	$('#left').css('border','solid 2px red');
			//  $('#left').css({'border':'solid 2px red', 'color':'blue'});
			//  $('p').html('<p>Tabby Cats</p>');
			// $('p').text('Tabby Cats');
			// $('p').html('<h2>Tabby Cats</h2>')
			// $('h2').text('give the H2 some text');
			// $('#left').css('color','blue').css('border','solid 2px red').fadeOut('20000');
			// $('p:last').addClass('para');
			// $('p:first').removeClass('para2');
			// $('p:first').toggleClass('para2');
			// $('#right').fadeIn(2500);
			// $('#center').fadeOut(2500);
			// $('#right').fadeIn(2500).fadeOut(2500);
			// $('#right').fadeTo(2500,0.5);
			// $('#right').fadeToggle(2500);
			// $('#right').append('<h2>We REALLY need a header</h2>');
			// $('#right').prepend('<h2>We REALLY need a header</h2>');
			// $('#right').after('<h2>We REALLY need a header</h2>');
			// $('#right').before('<h2>We REALLY need a header</h2>');
			// $('p').replaceWith('<p>new text everywhere</p>');
			// $('#right p').replaceWith('You just clicked a button');
			// $('#right p').remove();
			// $('div').remove();
			// $('img').attr('src', 'caesar2.jpeg');
			// $('img').removeAttr('src');


		});
		
		
	});