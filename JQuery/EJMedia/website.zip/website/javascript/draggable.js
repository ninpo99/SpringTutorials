     $(document).ready(function() {
          // $('.draggable').draggable({grid: [ 50,30]});
          // $('.draggable').draggable({containment: 'parent'},{grid: [ 50,30]});
          // $('.draggable').draggable({cursor: 'crosshair'});
          // $('.draggable').draggable({delay: '350'});
          // $('.draggable').draggable({revert: true});
          $('.draggable').draggable({axis:'y'});
   
     });
