     $(document).ready(function() {
          $('#maincontainer').tabs();
          // $('#maincontainer').tabs({active: 2});
          // $('#maincontainer').tabs({collapsible:true});
          // $('#maincontainer').tabs({});
          // $('#maincontainer').tabs({heightStyle:'fill'});
          // $('#maincontainer').tabs({heightStyle: 'content'});
          // $('#maincontainer').tabs({event: 'mouseover'});
          // $('#maincontainer').tabs({disabled:[ 1,2]});
          
     });
