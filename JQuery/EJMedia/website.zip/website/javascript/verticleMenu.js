     $(document).ready(function() {
          
            $('#verticleMenu').menu();
             // $("#verticleMenu").menu({icons: { submenu: "ui-icon-circle-triangle-e"}}, {menus: "div"});
             // $("#verticleMenu").menu({menus: "div"});
            // $('#box').dialog({title: 'Test Title'},{autoOpen: false});
            // $('#box').dialog({title: 'Test Title'},{autoOpen: true},{draggable: false},{resizable:false},{height: 200},{width: 200});
            // $('#box').dialog({show: 1500},{hide: 1500});
             // $("#box").dialog({show: "bounce",hide: "explode"},{closeOnEscape: false},{title: 'Test Title'},{autoOpen: true},{draggable: false},{resizable:false},{height: 400},{width: 400});
     		$('#box').dialog({modal: true})
     });
